/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimeragente;

import jade.core.*;


public class AgHolaMundo extends Agent {

protected void  setup(){
   
Object [] Listaparametros = getArguments();
String primerArgumento = (String) Listaparametros[0];
System.out.println("Hola mundo soy el primer agente" + getLocalName() + "Argumento" + primerArgumento);

}
    
}
