/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimeragente;

import jade.core.Agent;
import jade.domain.FIPAException;
import jade.domain.DFService;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.domain.FIPAAgentManagement.DFAgentDescription;


public class AgRegistrarServicio extends Agent{
    /**Crea una nueva instancia de RegistrarServico*/
    public String servicio;
    @Override
    protected void setup()
    {
     Object [] arg2 = getArguments();
     
     servicio = (String) arg2[0];
     
     System.out.println("El Nombre de Este Agente es :"+this.getLocalName() + " : Yo doy el Servicio" + servicio);
     registrerService();
    }
    private void registrerService()
    {
        DFAgentDescription dfd = new DFAgentDescription();
        dfd.setName(this.getAID()); 
        
        ServiceDescription sd = new ServiceDescription();
        sd.setType(servicio);
        sd.setName(servicio);
        
        dfd.addServices(sd);
        try{
            DFService.register(this,dfd);
        }
        catch(FIPAException ex)
        {
         System.err.println("El Agente :" + getLocalName() + "No ha Podido Registrar el Servicio :" + ex.getMessage());
         doDelete();
        }
    }
}
 