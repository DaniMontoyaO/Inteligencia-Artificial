/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package miprimeragente;

import jade.core.Agent;
import jade.core.behaviours.*;



public class AgComportamientoSimple extends Agent {
    
    
//Definicion de un comportamiento simple dentro de la clase
    class TareaSimple extends SimpleBehaviour {
        
    @Override
    public void action () {
       for (int i=0;i<10;i++)
          System.out.println("Ciclo " + i);
    }
        
    @Override
    public boolean done () {
       return true;
    }
    
    }
    @Override
    protected void setup()
    {
       System.out.println("Primer Agente Con Comportamiento JADE");
       TareaSimple cl = new TareaSimple();
       addBehaviour(cl);
    }

}